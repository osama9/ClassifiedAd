(function(){
	'use strict';


	angular.module('classified.controllers.ClassifiedListController',[]);
	angular.module('classified.controllers.CategoryListController',[]);

	angular.module('classified.services.ClassifiedService', [])
})();
